#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.*;

public class ${NAME} extends AbstractEntity {

}