#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import net.ent.etrs.squelette.model.facade.IFacadeMetier${NAME};

public class FacadeMetier${NAME}Impl implements IFacadeMetier${NAME} {
    
}