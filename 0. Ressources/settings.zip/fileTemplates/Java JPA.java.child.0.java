#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import net.ent.etrs.squelette.model.dao.base.BaseDao;
import net.ent.etrs.squelette.model.entities.${NAME};

public interface IDao${NAME} extends BaseDao<${NAME}> {

}