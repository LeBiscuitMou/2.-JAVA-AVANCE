#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import net.ent.etrs.squelette.model.dao.IDao${NAME};
import net.ent.etrs.squelette.model.dao.base.JpaBaseDao;
import net.ent.etrs.squelette.model.entities.${NAME};

public class Dao${NAME}Impl extends JpaBaseDao<${NAME}> implements IDao${NAME} {
}