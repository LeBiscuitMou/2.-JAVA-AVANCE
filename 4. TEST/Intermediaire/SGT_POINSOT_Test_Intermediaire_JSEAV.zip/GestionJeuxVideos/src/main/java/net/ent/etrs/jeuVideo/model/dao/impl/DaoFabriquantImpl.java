package net.ent.etrs.jeuVideo.model.dao.impl;

import net.ent.etrs.jeuVideo.model.dao.IDaoFabriquant;
import net.ent.etrs.jeuVideo.model.dao.base.JpaBaseDao;
import net.ent.etrs.jeuVideo.model.entities.Fabriquant;

public class DaoFabriquantImpl extends JpaBaseDao<Fabriquant> implements IDaoFabriquant {
}