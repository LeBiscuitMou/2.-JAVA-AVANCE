package net.ent.etrs.jeuVideo.model.dao;

import net.ent.etrs.jeuVideo.model.dao.base.BaseDao;
import net.ent.etrs.jeuVideo.model.entities.Fabriquant;

public interface IDaoFabriquant extends BaseDao<Fabriquant> {

}