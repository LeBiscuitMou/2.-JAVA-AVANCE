package net.ent.etrs.jeuVideo.model.entities.references;

public enum Pays {
    FRANCE,
    USA,
    JAPON,
    ALLEMAGNE
}
