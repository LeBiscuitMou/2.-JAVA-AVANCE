package net.ent.etrs.projetjavamaier.models.daos.impl;

import net.ent.etrs.projetjavamaier.models.daos.FabriquantDao;
import net.ent.etrs.projetjavamaier.models.daos.base.JpaBaseDao;
import net.ent.etrs.projetjavamaier.models.entities.Fabriquant;


public class DaoFabriquantImpl extends JpaBaseDao<Fabriquant> implements FabriquantDao {

}
