package net.ent.etrs.projetjavamaier.models.entities.references;

public enum Pays {
    FRANCE,
    USA,
    JAPON,
    ALLEMAGNE
}
