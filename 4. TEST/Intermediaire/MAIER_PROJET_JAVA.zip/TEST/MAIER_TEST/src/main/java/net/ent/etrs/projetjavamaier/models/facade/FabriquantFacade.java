package net.ent.etrs.projetjavamaier.models.facade;

import net.ent.etrs.projetjavamaier.models.entities.Fabriquant;
import net.ent.etrs.projetjavamaier.models.facade.base.FacadeMetier;

public interface FabriquantFacade extends FacadeMetier<Fabriquant> {

}