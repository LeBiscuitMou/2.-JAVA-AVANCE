package net.ent.etrs.projetjavamaier.models.daos;

import net.ent.etrs.projetjavamaier.models.daos.base.BaseDao;
import net.ent.etrs.projetjavamaier.models.entities.Fabriquant;

public interface FabriquantDao extends BaseDao<Fabriquant> {
    // This is the user interface
}