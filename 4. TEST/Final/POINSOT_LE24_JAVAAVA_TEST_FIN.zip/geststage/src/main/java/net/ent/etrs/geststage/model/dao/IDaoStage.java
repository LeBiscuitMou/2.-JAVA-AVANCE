package net.ent.etrs.geststage.model.dao;

import net.ent.etrs.geststage.model.dao.base.BaseDao;
import net.ent.etrs.geststage.model.entities.Stage;

public interface IDaoStage extends BaseDao<Stage> {

}