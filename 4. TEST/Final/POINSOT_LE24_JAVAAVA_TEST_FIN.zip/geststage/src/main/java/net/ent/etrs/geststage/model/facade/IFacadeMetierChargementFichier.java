package net.ent.etrs.geststage.model.facade;

import net.ent.etrs.geststage.model.facade.exceptions.BusinessException;

public interface IFacadeMetierChargementFichier {
    void initialisation() throws BusinessException;
}