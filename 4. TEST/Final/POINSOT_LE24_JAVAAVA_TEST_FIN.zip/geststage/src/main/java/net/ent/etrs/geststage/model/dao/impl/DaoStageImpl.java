package net.ent.etrs.geststage.model.dao.impl;

import net.ent.etrs.geststage.model.dao.IDaoStage;
import net.ent.etrs.geststage.model.dao.base.JpaBaseDao;
import net.ent.etrs.geststage.model.entities.Stage;

public class DaoStageImpl extends JpaBaseDao<Stage> implements IDaoStage {
}