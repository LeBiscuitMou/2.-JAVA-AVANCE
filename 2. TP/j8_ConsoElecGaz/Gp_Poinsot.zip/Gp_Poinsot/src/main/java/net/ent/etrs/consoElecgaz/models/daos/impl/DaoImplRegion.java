package net.ent.etrs.consoElecgaz.models.daos.impl;

import net.ent.etrs.consoElecgaz.models.daos.DaoRegion;
import net.ent.etrs.consoElecgaz.models.entities.Region;

import java.io.Serializable;

public class DaoImplRegion extends AbstractJpaDao<Region, Serializable> implements DaoRegion {


}