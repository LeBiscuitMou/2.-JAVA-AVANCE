package net.ent.etrs.consoElecgaz.models.daos;

import net.ent.etrs.consoElecgaz.models.entities.Region;

import java.io.Serializable;

public interface DaoRegion extends BaseDao<Region, Serializable> {
}
