package net.ent.etrs.consoElecgaz.models.daos.impl;

import net.ent.etrs.consoElecgaz.models.daos.DaoActivitePrincipale;
import net.ent.etrs.consoElecgaz.models.entities.ActivitePrincipale;

import java.io.Serializable;

public class DaoImplActivitePricipale extends AbstractJpaDao<ActivitePrincipale, Serializable> implements DaoActivitePrincipale {
}