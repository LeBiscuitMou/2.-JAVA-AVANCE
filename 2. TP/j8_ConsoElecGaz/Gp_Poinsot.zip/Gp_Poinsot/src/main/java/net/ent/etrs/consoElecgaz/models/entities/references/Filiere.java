package net.ent.etrs.consoElecgaz.models.entities.references;

public enum Filiere {
    ELECTRICITE,
    GAZ
}
