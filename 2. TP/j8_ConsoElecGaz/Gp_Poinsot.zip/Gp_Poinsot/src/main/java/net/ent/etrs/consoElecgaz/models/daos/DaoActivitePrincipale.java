package net.ent.etrs.consoElecgaz.models.daos;

import net.ent.etrs.consoElecgaz.models.entities.ActivitePrincipale;

import java.io.Serializable;

public interface DaoActivitePrincipale extends BaseDao<ActivitePrincipale, Serializable> {
}
