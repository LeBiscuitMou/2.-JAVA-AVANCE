package net.ent.etrs.consoElecgaz.models.facades;

public interface IFacadeChargementFichier {
    void initialisation() throws Exception;
}
