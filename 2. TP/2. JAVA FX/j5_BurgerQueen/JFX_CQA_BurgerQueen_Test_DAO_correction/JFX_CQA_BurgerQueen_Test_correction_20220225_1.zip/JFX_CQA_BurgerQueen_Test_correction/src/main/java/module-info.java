open module BurgerQueen {
    requires javafx.controls;
    requires javafx.fxml;
    requires static lombok;
    requires java.persistence;
    requires java.validation;
    requires java.sql;
    requires org.apache.commons.collections4;

    requires org.hibernate.validator;
    requires org.hibernate.orm.core;

    requires commons.logging;

}
