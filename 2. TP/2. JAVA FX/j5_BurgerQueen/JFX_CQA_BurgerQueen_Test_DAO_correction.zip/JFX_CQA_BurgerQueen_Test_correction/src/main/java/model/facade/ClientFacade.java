package model.facade;

import java.util.List;

import model.entities.Client;

public interface ClientFacade {

	void initialisationClient();

	Client searchClientByNomPrenom(String string, String string2);

	List<Client> findAll();

	Client save(Client clientAModifier);

	void delete(Client c);

}