package model.dao;

import java.io.Serializable;
import java.util.List;

import model.dao.base.BaseDao;
import model.entities.Client;
import model.entities.Commande;

public interface DaoCommande extends BaseDao<Commande, Serializable> {

//	public void initialisation(ClientFacade facadeClient, ProduitFacade facadeProduit) throws BusinessException;

	public List<Commande> searchCommandeByClient(Client client);

}
