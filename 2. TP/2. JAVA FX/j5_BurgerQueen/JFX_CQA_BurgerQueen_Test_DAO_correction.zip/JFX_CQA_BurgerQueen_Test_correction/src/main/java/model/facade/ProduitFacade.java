package model.facade;

import java.util.List;

import model.entities.Produit;
import model.references.TailleProduit;
import model.references.TypeProduit;

public interface ProduitFacade {

	void initialisationProduit();

	Produit searchProduitByNomPrenom(String nom, TypeProduit typeProduit, TailleProduit tailleProduit);

	List<Produit> findAll();


}