package model.references;

public enum TypeProduit {

	BOISSON,
	SANDWICH,
	FRITE,
	POTATOES
}
