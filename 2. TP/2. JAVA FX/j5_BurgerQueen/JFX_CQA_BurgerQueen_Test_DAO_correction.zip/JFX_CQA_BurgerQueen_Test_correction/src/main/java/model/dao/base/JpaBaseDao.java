package model.dao.base;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

//import org.eclipse.persistence.config.QueryHints;

import lombok.Getter;
import lombok.Setter;

public abstract class JpaBaseDao<T, ID> implements BaseDao<T, Serializable> {

	@Getter
	protected Class<T> entityClass;

	@Getter
	@Setter
	protected EntityManager entityManager;

	public JpaBaseDao() {
		ParameterizedType genericSuperClass = (ParameterizedType) this.getClass().getGenericSuperclass();
		this.entityClass = (Class<T>) genericSuperClass.getActualTypeArguments()[0];
	}

	@Override
	public <S extends T> S save(S entity) {
		S toto = null;
		if (entity != null) {
			EntityTransaction et = this.entityManager.getTransaction();
			et.begin();
			try {
				System.out.println("entity avant merge : " + entity);
				toto = this.entityManager.merge(entity);
				et.commit();
				System.out.println("entity apres merge : " + toto);
			} catch (Exception e) {
				et.rollback();
			}
		}
		return toto;
	}

	@Override
	public T findOne(Serializable id) {
		return this.entityManager.find(this.entityClass, id);
	}

//    @Override
//    public Iterable<T> findAll() {
//        return this.entityManager
//                .createQuery("SELECT t FROM " + this.entityClass.getSimpleName() + " t"
//                        , this.entityClass)
//                .getResultList();
//    }

	@Override
	public Iterable<T> findAll() {
		EntityTransaction et = this.entityManager.getTransaction();
		et.begin();
		TypedQuery<T> q = this.entityManager.createQuery("SELECT t FROM " + this.entityClass.getSimpleName() + " t", this.entityClass);
		this.entityManager.clear();
		List<T> lst = q.getResultList();
		et.commit();
		return lst;
	}

	@Override
	public void delete(T entity) {
		if (entity != null) {
			EntityTransaction et = this.entityManager.getTransaction();
			et.begin();
			try {
				this.entityManager.remove(entity);
				et.commit();
			} catch (Exception e) {
				et.rollback();
			}
		}
	}

	@Override
	public void delete(Serializable id) {
		T entity = this.findOne(id);
		this.delete(entity);
	}

	@Override
	public boolean exists(Serializable id) {
		return this.findOne(id) != null;
	}

	@Override
	public long count() {
		TypedQuery<Long> q = this.entityManager
				.createQuery("SELECT COUNT(t) FROM " + this.entityClass.getSimpleName() + " t", Long.class);
		return q.getSingleResult();
	}
}
