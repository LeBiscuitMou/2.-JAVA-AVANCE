package model.references;

public enum TailleProduit {

	PETIT,
	MOYEN,
	GRAND
}
