package model.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections.IteratorUtils;

import model.entities.Client;
import model.entities.EntitiesFactory;

public class ClientFacadeImpl extends AbstractFacade<Client> implements ClientFacade {

	@Override
	public void initialisationClient() {
		List<Client> lstClients = new  ArrayList<>();
		
		lstClients.add(EntitiesFactory.fabriquerClient("toto", "totop", "toto@g"));
		lstClients.add(EntitiesFactory.fabriquerClient("titi", "titip", "titi@g"));
		lstClients.add(EntitiesFactory.fabriquerClient("alf", "raid", "alf@g"));
		lstClients.add(EntitiesFactory.fabriquerClient("dark", "queen", "dark.queen@g"));
		lstClients.add(EntitiesFactory.fabriquerClient("Udutorse", "paul", "paul.udutore@g"));
		
		
		lstClients.forEach((p)->rechercherCreerClient(p));
		
		
		
	}

	private void rechercherCreerClient(Client c) {
		if (Objects.isNull(this.daoClient.searchClientByNomPrenom(c.getNom(), c.getPrenom()))) {
			this.daoClient.save(c);
		}
	}

	@Override
	public Client searchClientByNomPrenom(String nom, String prenom) {
		return this.daoClient.searchClientByNomPrenom(nom, prenom);
	}

	@Override
	public List<Client> findAll() {
		return IteratorUtils.toList(this.daoClient.findAll().iterator());
	}

	@Override
	public Client save(Client c) {
		return this.daoClient.save(c);
	}

	@Override
	public void delete(Client c) {
		this.daoClient.delete(c);
	}

	
	
}
