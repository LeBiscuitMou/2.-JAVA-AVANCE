package model.dao;

import java.io.Serializable;

import model.dao.base.BaseDao;
import model.entities.Client;

public interface DaoClient extends BaseDao<Client, Serializable>{

	public void initialisationClient();

	public Client searchClientByNomPrenom(String nom, String prenom);

}
