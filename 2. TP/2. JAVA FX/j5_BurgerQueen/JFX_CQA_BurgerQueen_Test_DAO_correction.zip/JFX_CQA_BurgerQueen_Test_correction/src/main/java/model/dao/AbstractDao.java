package model.dao;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import model.dao.base.JpaBaseDao;


public class AbstractDao<T,K> extends JpaBaseDao<T,K>  {
	
	private static EntityManager em = Persistence.createEntityManagerFactory("JFX_CQA_BurgerQueen").createEntityManager();

	public AbstractDao() {
		if(em == null) {
			em = Persistence.createEntityManagerFactory("JFX_CQA_BurgerQueen").createEntityManager();
		}
		this.entityManager = em;
	}

}
