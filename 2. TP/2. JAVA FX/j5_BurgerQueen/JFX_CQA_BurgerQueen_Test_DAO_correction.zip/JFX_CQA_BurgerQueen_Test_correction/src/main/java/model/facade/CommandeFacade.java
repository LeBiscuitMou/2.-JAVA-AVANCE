package model.facade;

import java.util.List;

import model.entities.Client;
import model.entities.Commande;

public interface CommandeFacade {

	void initialisation(ClientFacade facadeClient, ProduitFacade facadeProduit);

	List<Commande> searchCommandeByClient(Client client);

	Commande save(Commande commandeAModifier);

}