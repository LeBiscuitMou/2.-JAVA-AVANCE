package model.facade;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections.IteratorUtils;

import model.entities.EntitiesFactory;
import model.entities.Produit;
import model.references.TailleProduit;
import model.references.TypeProduit;

public class ProduitFacadeImpl extends AbstractFacade<Produit> implements ProduitFacade {

	@Override
	public void initialisationProduit() {
		List<Produit> lstProduits = new  ArrayList<>();
		
		lstProduits.add(EntitiesFactory.fabriquerProduit("burger", TailleProduit.PETIT, new BigDecimal(2), TypeProduit.SANDWICH));
		lstProduits.add(EntitiesFactory.fabriquerProduit("double miche", TailleProduit.PETIT, new BigDecimal(2), TypeProduit.SANDWICH));
		lstProduits.add(EntitiesFactory.fabriquerProduit("double miche", TailleProduit.MOYEN, new BigDecimal(3), TypeProduit.SANDWICH));
		lstProduits.add(EntitiesFactory.fabriquerProduit("double miche", TailleProduit.GRAND, new BigDecimal(4), TypeProduit.SANDWICH));
		lstProduits.add(EntitiesFactory.fabriquerProduit("coca", TailleProduit.PETIT, new BigDecimal(1), TypeProduit.BOISSON));
		lstProduits.add(EntitiesFactory.fabriquerProduit("coca", TailleProduit.MOYEN, new BigDecimal(1.5), TypeProduit.BOISSON));
		lstProduits.add(EntitiesFactory.fabriquerProduit("coca", TailleProduit.GRAND, new BigDecimal(2), TypeProduit.BOISSON));
		lstProduits.add(EntitiesFactory.fabriquerProduit("patatoes", TailleProduit.PETIT, new BigDecimal(1), TypeProduit.POTATOES));
		lstProduits.add(EntitiesFactory.fabriquerProduit("tiges blondes", TailleProduit.PETIT, new BigDecimal(1), TypeProduit.FRITE));
		lstProduits.add(EntitiesFactory.fabriquerProduit("tiges blondes", TailleProduit.MOYEN, new BigDecimal(1.5), TypeProduit.FRITE));
		lstProduits.add(EntitiesFactory.fabriquerProduit("tiges blondes", TailleProduit.GRAND, new BigDecimal(2), TypeProduit.FRITE));
		
		lstProduits.forEach((p)->rechercherCreerProduit(p));
		
		
		
		}

		private void rechercherCreerProduit(Produit p) {
			if (Objects.isNull(this.searchProduitByNomPrenom(p.getNom(), p.getTypeProduit(), p.getTailleProduit()))) {
				this.daoProduit.save(p);
			}
		}

		@Override
		public Produit searchProduitByNomPrenom(String nom, TypeProduit typeProduit, TailleProduit tailleProduit) {
			return this.daoProduit.searchProduitByNomPrenom(nom, typeProduit, tailleProduit);
		}

		@Override
		public List<Produit> findAll() {
			return IteratorUtils.toList(this.daoProduit.findAll().iterator());
		}
	
}
