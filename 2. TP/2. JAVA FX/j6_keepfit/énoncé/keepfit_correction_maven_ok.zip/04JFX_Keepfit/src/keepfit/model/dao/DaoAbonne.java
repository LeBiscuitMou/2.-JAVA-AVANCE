package keepfit.model.dao;

import java.util.UUID;

import keepfit.model.entities.Abonne;

public interface DaoAbonne extends Dao<Abonne,UUID> {

	//méthodes specifiques aux abonnés
}
