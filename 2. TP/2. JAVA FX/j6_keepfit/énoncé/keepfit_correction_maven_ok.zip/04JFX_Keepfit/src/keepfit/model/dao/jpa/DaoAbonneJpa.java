package keepfit.model.dao.jpa;

import java.util.List;

import javax.persistence.TypedQuery;

import keepfit.model.dao.DaoAbonne;
import keepfit.model.dao.DaoException;
import keepfit.model.entities.Abonne;

public class DaoAbonneJpa extends AbstractDao implements DaoAbonne {

	@Override
	public void create(Abonne t) throws DaoException {
		em.getTransaction().begin();	
		em.persist(t);
		em.getTransaction().commit();
	}
	
	@Override
	public List<Abonne> readAll() throws DaoException {
		TypedQuery<Abonne> q = em.createNamedQuery("readAllAbonnes",Abonne.class);
		return q.getResultList();
	}
	
	@Override
	public void delete(Abonne t) throws DaoException {
		em.getTransaction().begin();		
		em.remove(t);
		em.getTransaction().commit();
	}
	
	@Override
	public void update(Abonne t) throws DaoException {
		em.getTransaction().begin();		
		em.merge(t);
		em.getTransaction().commit();
	}
}
