package keepfit.model.exceptions;

/**
 * Calsse de messages d'exceptions métiers
 * @author nicolas.magniez
 *
 */
public final class Messages {

	private Messages() {
		// TODO Auto-generated constructor stub
	}
	
	public static final String MSG_="";
	public static final String MSG_1="";
	public static final String MSG_2="";
	public static final String MSG_3="";
	public static final String MSG_4="";
	
}
