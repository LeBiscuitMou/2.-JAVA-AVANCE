package keepfit.model.entities;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import keepfit.model.dao.jpa.RequetesJpql;

//Annotations JPA
@SuppressWarnings("serial")
@Table(name="PRESTATION")
@Entity

//Annotations Lombok

@NamedQueries(value= {
		@NamedQuery(name="readAllPrestations",query=RequetesJpql.REQUETE_READALL_PRESTATIONS),
		@NamedQuery(name="compterPrestations",query=RequetesJpql.REQUETE_COMPTER_PRESTATIONS)	
		
})
public class Prestation extends AbstractEntity {
	
	@Column(name="LIBELLE")
	private String libelle;
	
	@Column(name="COUT")
	private BigDecimal cout;
		
	public Prestation() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see model.entities.IPrestation#getLibelle()
	 */
	public String getLibelle() {
		return libelle;
	}

	/* (non-Javadoc)
	 * @see model.entities.IPrestation#setLibelle(java.lang.String)
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	/* (non-Javadoc)
	 * @see model.entities.IPrestation#getCout()
	 */
	public BigDecimal getCout() {
		return cout;
	}

	/* (non-Javadoc)
	 * @see model.entities.IPrestation#setCout(java.math.BigDecimal)
	 */
	public void setCout(BigDecimal cout) {
		this.cout = cout;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Prestation [libelle=");
		builder.append(libelle);
		builder.append(", cout=");
		builder.append(cout);
		builder.append(", getId()=");
		builder.append(getId());
		builder.append("]");
		return builder.toString();
	}
	
	
}
