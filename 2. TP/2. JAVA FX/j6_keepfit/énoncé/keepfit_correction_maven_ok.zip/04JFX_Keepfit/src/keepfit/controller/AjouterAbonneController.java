package keepfit.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import keepfit.model.entities.Abonne;
import keepfit.model.exceptions.BusinessException;

public class AjouterAbonneController extends AbstractController{	
	
	@FXML private TextField tfNom;
	
	@FXML private TextField tfPrenom;
	
	@FXML private DatePicker dpDateInscription;
	
	private ObservableList<Abonne> olstAbonnes;
	
	Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
	
//	public AjouterAbonneController(ObservableList<Abonne> abonnes) {		
//		this.olstAbonnes=abonnes;
//	}
	
	@FXML
	public void ajouter() throws IOException{
		Abonne nouvelAbonne;
		if ( dpDateInscription.getValue()!=null){
			nouvelAbonne = new Abonne(tfNom.getText(),tfPrenom.getText(),dpDateInscription.getValue());
		}else{
			//Si pas de date choisie je mets la date du jour par défaut
			nouvelAbonne = new Abonne(tfNom.getText(),tfPrenom.getText(),LocalDate.now());
		}
		
		//je passe le nouvel abonné au validator
		Set<ConstraintViolation<Abonne>> violations=validator.validate(nouvelAbonne);
		
		if (violations.size()>0){
			//Si constrainte(s) de validation violée(s)
			Alert alerte = new Alert(AlertType.ERROR);
			StringBuilder sb= new StringBuilder();
			for (ConstraintViolation<Abonne> violation : violations) {
				sb.append(violation.getMessage()+"\n");
			}
			
			alerte.setContentText(sb.toString());
			alerte.showAndWait();
		}else{
			//Sinon j'ajoute en base
			try {
				getLeMetier().creerUnAbonne(nouvelAbonne);
			} catch (BusinessException e) {
				Alert a = new Alert(AlertType.ERROR,e.getMessage());
				a.showAndWait();
			}
			
			Scene sceneCourante =  tfNom.getScene();
			sceneCourante.setRoot(FXMLLoader.load(this.getClass().getResource("/keepfit/view/ListerAbonnes.fxml")));		
		}		
	}	
}
