package keepfit.model.entities;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import keepfit.model.dao.jpa.RequetesJpql;

@SuppressWarnings("serial")
@Entity
@Table(name="ABONNE")

@NamedQueries(value= {
		@NamedQuery(name="readAllAbonnes",query=RequetesJpql.REQUETE_READALL_ABONNES)			
		
})
public class Abonne extends AbstractEntity {
	
	private final static BigDecimal ABONNEMENT_BASE= new BigDecimal("120");
	
	@Pattern(regexp="[A-Za-z]*", message="Le nom ne doit contenir que des lettres")
	@Column(name="NOM")
	private String nom;

	@Pattern(regexp="[A-Za-z]*", message="Le prenom ne doit contenir que des lettres")
	@Column(name="PRENOM")
	private String prenom;
	
	@Column(name="DATE_INSCRIPTION")
	private LocalDate dateInscription;
	
	/* (non-Javadoc)
	 * @see model.entities.IAbonne#getDateInscription()
	 */
	public LocalDate getDateInscription() {
		return dateInscription;
	}

	@ManyToMany	
	@JoinTable(name="ABONNE_PRESTATION", joinColumns=@JoinColumn(name="ABONNE_ID"),inverseJoinColumns=@JoinColumn(name="PRESTATION_ID"))
	private List<Prestation> lstPrestations = new ArrayList<>();
	

	/* (non-Javadoc)
	 * @see model.entities.IAbonne#getLstPrestations()
	 */
	public List<Prestation> getLstPrestations() {
		return lstPrestations;
	}

	public Abonne() {
		// TODO Auto-generated constructor stub
	}

	public Abonne(String nom, String prenom,LocalDate dateInscription) {
		this.nom=nom;        
		this.prenom=prenom;
		this.dateInscription=dateInscription;
	}	

	/* (non-Javadoc)
	 * @see model.entities.IAbonne#getNom()
	 */
	public String getNom() {
		return nom;
	}


	/* (non-Javadoc)
	 * @see model.entities.IAbonne#setNom(java.lang.String)
	 */
	public void setNom(String nom) {
		this.nom=nom;
	}

	/* (non-Javadoc)
	 * @see model.entities.IAbonne#getPrenom()
	 */
	public String getPrenom() {
		
		return prenom;
	}

	/* (non-Javadoc)
	 * @see model.entities.IAbonne#setPrenom(java.lang.String)
	 */
	public void setPrenom(String prenom) {
		this.prenom=prenom;
		
	}	

	/* (non-Javadoc)
	 * @see model.entities.IAbonne#souscrire(model.entities.Prestation)
	 */
	public void souscrire(Prestation p){
		this.lstPrestations.add(p);
	}
	
	/* (non-Javadoc)
	 * @see model.entities.IAbonne#resilier(model.entities.Prestation)
	 */
	public void resilier(Prestation p){
		this.lstPrestations.remove(p);
	}
	
	/* (non-Javadoc)
	 * @see model.entities.IAbonne#calculerAbonnement()
	 */
	public BigDecimal calculerAbonnement(){
		BigDecimal total = ABONNEMENT_BASE;
		for (Prestation prestation : lstPrestations) {
			total = total.add(prestation.getCout());
		}
		return total;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Abonne [nom=");
		builder.append(nom);
		builder.append(", prenom=");
		builder.append(prenom);
		builder.append(", dateInscription=");
		builder.append(dateInscription);
		builder.append(", lstPrestations=");
		builder.append(lstPrestations);
		builder.append(", getId()=");
		builder.append(getId());
		builder.append("]");
		return builder.toString();
	}

}
