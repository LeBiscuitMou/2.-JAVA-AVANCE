package keepfit.model.facade;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import keepfit.model.dao.DaoException;
import keepfit.model.dao.DaoFactory;
import keepfit.model.dao.jpa.DaoAbonneJpa;
import keepfit.model.dao.jpa.DaoPrestationJpa;
import keepfit.model.entities.Abonne;
import keepfit.model.entities.Prestation;
import keepfit.model.exceptions.BusinessException;
import keepfit.model.exceptions.Messages;

public class FacadeMetier implements IFacadeMetier {
	
	//Besoin de persistence JPA Abonne et Prestation
	private DaoAbonneJpa persistanceA = DaoFactory.fabriquerDaoAbonneJpa();
	private DaoPrestationJpa persistanceP = DaoFactory.fabriquerDaoPrestationJpa();
	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#initPrestation()
	 */
	@Override
	public void initialiserDesPrestations() {
		if (!persistanceP.existeDejaDesPrestations()) {
			try {
				List<String> lst = Files.readAllLines(Paths.get("prestations.txt"));
				for (String ligne : lst) {
					String[] tab = ligne.split("=");
					Prestation p = new Prestation();
					p.setLibelle(tab[0]);
					p.setCout(new BigDecimal(tab[1]));
					persistanceP.create(p);
				}
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DaoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}
		
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#creerUnAbonne(keepfit.model.entities.Abonne)
	 */
	@Override
	public void creerUnAbonne(Abonne a) throws BusinessException {		
		try {
			persistanceA.create(a);
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}		
	}	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#supprimerUnAbonne(keepfit.model.entities.Abonne)
	 */
	@Override
	public void supprimerUnAbonne(Abonne a) throws BusinessException {		
		try {
			persistanceA.delete(a);
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}			
	}	
	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#listerLesAbonnes()
	 */
	@Override
	public List<Abonne> listerLesAbonnes() throws BusinessException {
		try {
			return this.persistanceA.readAll();
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}	
	}	
	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#listerLesPrestations()
	 */
	@Override
	public List<Prestation> listerLesPrestations() throws BusinessException {
		try {
			return this.persistanceP.readAll();
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}	
	}	
	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#ajouterPrestationAbonne(keepfit.model.entities.Prestation, keepfit.model.entities.Abonne)
	 */
	@Override
	public void ajouterPrestationAbonne(Prestation p, Abonne a) throws BusinessException{
		a.souscrire(p);
		//Ne pas oublier de mettre a jour l'abonné
		try {
			persistanceA.update(a);
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}
	}
	
	/* (non-Javadoc)
	 * @see keepfit.model.facade.IFacadeMetier#supprimerPrestationAbonne(keepfit.model.entities.Prestation, keepfit.model.entities.Abonne)
	 */
	@Override
	public void supprimerPrestationAbonne(Prestation p, Abonne a) throws BusinessException{
		a.resilier(p);
		try {
			persistanceA.update(a);
		} catch (DaoException e) {
			throw new BusinessException(Messages.MSG_);
		}
	}
	

	
}
