package keepfit.model.dao.jpa;

public final class RequetesJpql {
	private RequetesJpql() {
		// TODO Auto-generated constructor stub
	}
	
	public final static String REQUETE_READALL_ABONNES="SELECT a FROM Abonne a";
	public final static String REQUETE_READALL_PRESTATIONS="SELECT p FROM Prestation p";
	public final static String REQUETE_COMPTER_PRESTATIONS="SELECT COUNT(p) FROM Prestation p";
	
}
