package keepfit.controller;

import keepfit.model.facade.FacadeFactory;
import keepfit.model.facade.IFacadeMetier;


public class AbstractController {
	private IFacadeMetier leMetier; 
	
	public AbstractController() {
		this.leMetier= FacadeFactory.fabriquerFacadeMetier();
		leMetier.initialiserDesPrestations();
	}
	
	public IFacadeMetier getLeMetier() {
		return leMetier;
	}
	
}
