package keepfit.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import keepfit.model.entities.Abonne;
import keepfit.model.entities.Prestation;
import keepfit.model.exceptions.BusinessException;

public class EditerAbonneController extends AbstractController {

	@FXML
	private GridPane monPanneauGrid;

	@FXML
	private VBox vbox;
	
	@FXML
	private Button btnModif;

	@FXML
	private Label leLabel;
	
	private ObservableList<Prestation> olstPrestations = FXCollections.observableArrayList();
		
	private Abonne abonneModif;
	
	public void setAbonneModif(Abonne abonneModif) {
		this.abonneModif = abonneModif;
	}
	
	//Necessaire pour les boutons à cocher(CheckBox)
	Map<CheckBox,Prestation> map = new HashMap<>();
	
	@FXML
	private void initialize() {
		leLabel.setText(String.format("Prestations pour %s", this.abonneModif.getNom()));
		//je recupere le referentiel des prestations de la base de données
		try {
			olstPrestations.addAll(getLeMetier().listerLesPrestations());
		} catch (BusinessException e) {
			Alert a = new Alert(AlertType.ERROR,e.getMessage());
			a.showAndWait();
		}
		
		//Pour chaque prestation je crée un checkbox associé ( que j'ajoute a la VBox)
		//L'association Prestation-CheckBox se fait grace a une Map
		for (Prestation p : olstPrestations) {
			CheckBox cb = new CheckBox(p.getLibelle());
			vbox.getChildren().add(cb);
			map.put(cb, p);
			//Pré-remplir (cocher) les checkbox des prestations déjà souscrites
			if (this.abonneModif.getLstPrestations().contains(p)){
				cb.setSelected(true);
			}
		}	
	}
	

	public void modifier() throws IOException{			
		//Pour chaque coche
		for (CheckBox cb : map.keySet()) {
			//Si le bouton n'est pas coché
			//Et que l'abonné a la prestation souscrite
			if (!cb.isSelected() && abonneModif.getLstPrestations().contains(map.get(cb))){
				//Je resilie la prestation
				try {
					getLeMetier().supprimerPrestationAbonne(map.get(cb), abonneModif);
				} catch (BusinessException e) {
					Alert a = new Alert(AlertType.ERROR,e.getMessage());
					a.showAndWait();
				}
			}
			//Si le bouton est coché
			//Et que l'abonné n'a pas la prestation souscrite
			if (cb.isSelected() && !abonneModif.getLstPrestations().contains(map.get(cb))){				
				//Je souscris la prestation
				try {
					getLeMetier().ajouterPrestationAbonne(map.get(cb),abonneModif);
				} catch (BusinessException e) {
					Alert a = new Alert(AlertType.ERROR,e.getMessage());
					a.showAndWait();
				}
			}
		}			
		
		//Je reviens à l'ecran principal
		Scene sceneCourante =  monPanneauGrid.getScene();
		AnchorPane vuePrincipale = (AnchorPane) FXMLLoader.load(this.getClass().getResource("/keepfit/view/ListerAbonnes.fxml"));       
		sceneCourante.setRoot(vuePrincipale);
	}

	
		
}
