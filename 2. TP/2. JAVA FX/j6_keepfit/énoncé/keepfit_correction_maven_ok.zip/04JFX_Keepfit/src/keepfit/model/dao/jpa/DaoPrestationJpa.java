package keepfit.model.dao.jpa;

import java.util.List;

import javax.persistence.TypedQuery;

import keepfit.model.dao.DaoException;
import keepfit.model.dao.DaoPrestation;
import keepfit.model.entities.Prestation;

public class DaoPrestationJpa extends AbstractDao implements DaoPrestation {	
	
	/**
	 * Pour l'initialisation éventuelle
	 */
	@Override
	public void create(Prestation t) throws DaoException {
		em.getTransaction().begin();		
		em.persist(t);
		em.getTransaction().commit();
	}
	
	@Override
	public boolean existeDejaDesPrestations() {
		TypedQuery<Long> q = em.createNamedQuery("compterPrestations",Long.class);		
		return q.getSingleResult()!=0;
	}
	
	/**
	 * Pour l'ecran de modification d'un abonné
	 */
	@Override
	public List<Prestation> readAll() throws DaoException {
		TypedQuery<Prestation> q = em.createNamedQuery("readAllPrestations",Prestation.class);
		return q.getResultList();
	}


}
